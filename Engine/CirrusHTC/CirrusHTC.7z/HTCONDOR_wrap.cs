﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;



namespace CIRRUS_HTC_NS
{
    public  class CIRRUS_HTC

    {
        // type 1: required variables     (job not set
        private string chtc_executable = "";                //tested and supported: swmm5.exe, extendsim8, pro2d2
        private string chtc_arguments = "";
        private string chtc_initialdir = "";
        //type 2: optional customization
        private string chtc_should_transfer_files = "";
        private string chtc_when_to_transfer_output = "";
        private string chtc_queue = "";
        private string chtc_requirements = "";
        //type 3: optional additional helpers
        private string chtc_IsSimLink = "N";
        private string chtc_SimLinkConnectionString = "";

        //or

        public Dictionary<string, string> dictCHTC_Spec;
        public Dictionary<string, string> _dictCHTC_Args;       //read in args from CLI or prepare from UI

        private bool _bCreateCondorRunFolder = false;           //set true if loading to a central location (like server)
        public HTC_SimType _SimType;                         //
        private bool _IsUNC = false;
        private bool bIsSimLink = false;
        protected bool _bOutputIsInput = false;                        //true for things like ExtendSim, XLS - presents challenge to HTC which fails in some cases.
        private string sJobDirectory;
        protected string _sCirrusHTC_WorkingDir = @"C:\Users\mthroneb\Documents\Optimization\Cirrus\JobCenter";      //todo: read from config
        public const string _sZipFileName = "files.7z";
        public string _sActiveHTCDir = "UNDEFINED";                   // the directory where the htc job will be assembled
        public int nStandardConfig;                         // this holds something like ActiveModelID          val = 0 NONSTANDARD val =-1 LAZY OTHER: model-specific standard config
      //  public string sExecutableClientLocation =@"C:\Program Files\EPA_SWMM_5022\swmm5.exe";               //todo: massively improve this- hard coded to get off ground
        private string sLOC_7ZIP = @"C:\Program Files\7Zip\7za.exe";
        private string sLOC_SWMM = @"C:\Program Files\EPA_SWMM_5022\swmm5.exe";
        const string sSubCondorFile = "run_condor.sub";
        private CIRRUS_HTC_NS.CommonUtilities cu = new CIRRUS_HTC_NS.CommonUtilities();

        private long lTimestampBeginHTC;                    //used to track when a 

        #region Constructors
 
        public CIRRUS_HTC()
        {
            dictCHTC_Spec = CHTC_CreateTemplate();                          //initialize the default CondorSpecification dictioanry
        }
        #endregion Constructors

        #region enum
        protected enum HTC_REQ_SOFTWARE
        {
            HasEXTENDSIM,
            HasSWMM,
            HasEPANET,
            HasPREVIEW
        }

        public enum HTC_SimType
        {
            InputFile,
            ZipFile,
            Undefined
        }


        #endregion

        //met 8/28/2013 - initialize arg array
        //returns the filenames, which are critical for the call to PreProcessCondor
        public string[] chtcInitArgDict(string[] args)                 // pause on this for now    , out bool bIsValid)
        {
            List<string> lstFileNames = new List<string>();
            _dictCHTC_Args = CommonUtilities.Arguments_ToDict(args);
            if (_dictCHTC_Args.ContainsKey("f"))
            {
                chtcArgsHelper_GetFilename(_dictCHTC_Args["f"].ToString(), ref lstFileNames);
            }
         //   bIsValid = lstFileNames.Count>0;
            return lstFileNames.ToArray();
        }

        //met 8/28/2013
        //input: assume a well-formed REQUIREMENT string
        //update the req dict entry to work with this
        protected void argREQUIREMENT_Update()
        {
            if (_dictCHTC_Args.ContainsKey("req")){
                if (dictCHTC_Spec["requirements"].ToString()=="true")
                {
                    dictCHTC_Spec["requirements"] = _dictCHTC_Args["req"];
                }
                else{
                    dictCHTC_Spec["requirements"] = "((" + dictCHTC_Spec["requirements"] + ") AND " + _dictCHTC_Args["req"] + ")";
                }
            }
        }

        //adds files to list of strings (if there is a good filename)
        private void chtcArgsHelper_GetFilename(string sFilesConcat, ref List<string> lstFiles)
        {
            char sDelimiter = ',';                    //todo: support "file1.inp file2.inp" in cases where full path does not contain strings
            string[] sFiles = sFilesConcat.Split(sDelimiter);
            foreach (string s in sFiles)
            {
                if (Path.GetFileName(s).IndexOfAny(Path.GetInvalidFileNameChars()) < 0){        //check for valid file name. not a complete check, but a start.
                    lstFiles.Add(s);
                }
            }
        }

        //met: todo: consider using string[] args to be more similar to API
        //dictionary seems cleaner.
        public bool CHTC_CreateCLI(string sFileName)
        {
            File.WriteAllLines(sFileName, CHTC_DictToArray(dictCHTC_Spec));
            return true;            //todo: return false if problem with process
        }

        //convert dictionary to array
        public string[] CHTC_DictToArray(Dictionary<string, string> dictCustomVals)
        {
            List<string> list = new List<string>();
            int nIndex = 0;
            foreach (KeyValuePair<string, string> pair in dictCustomVals)
            {
                if (WriteOutKVP(pair))          
                {
                    list.Add( pair.Key + " = " + pair.Value);
                    nIndex++;
                }
            }
            return list.ToArray();
        }

        //function for determining whether to write out line
        //may get complicated
        private bool WriteOutKVP(KeyValuePair<string, string> pair)
        {
            bool bReturn = true;
            if (pair.Value == "XXX")
            {
                bReturn = false;
            }
            else if (pair.Key.Substring(0,3) == "car"){             //max three characters at this point
                bReturn = false;
            }
            return bReturn;
        }

        public void HTC_Submit(bool bSkipCreateSubmit = false)
        {
            string sSubCondorLocal = sSubCondorFile;                // overwrite with path if needed for UNC execution
            if (!bSkipCreateSubmit)
                CHTC_CreateCLI(_sActiveHTCDir + sSubCondorFile);        // create CLI file
            if ((dictCHTC_Spec["should_transfer_files"].ToString() == "YES") && _bCreateCondorRunFolder)        //met 8/25/2013- added runfolder test... may need more dtl for exe (copy exe but not files, eg)
            {
                HTC_PrepareFiles();
            }

            if (_IsUNC)
            {
                sSubCondorLocal = _sActiveHTCDir + sSubCondorFile;
            }
            
            /////////////create the beautiful condor file which will be executed...
            string sBatchRun = _sActiveHTCDir + "condor.bat";
            using (StreamWriter writer = new StreamWriter(sBatchRun))
            {
                writer.WriteLine("cd %~dp0");              //change to current location
                writer.WriteLine("condor_submit " + sSubCondorLocal);
               // writer.WriteLine("pause");
            }
            CommonUtilities.cuRunBatchFile(sBatchRun, false);
        }


        //todo : consider how this will work differently when driven by SimLink

        private void HTC_PrepareFiles()
        {
            string[] sFiles;

            //////////////STEP 1: Transfer the needed files
            if (dictCHTC_Spec.ContainsKey("carg_transferfiles"))
            {
                sFiles = dictCHTC_Spec["carg_transferfiles"].Split(';');
                foreach (string sFile in sFiles)
                {
                    string sTarget = _sActiveHTCDir + System.IO.Path.GetFileName(sFile);
                    if (File.Exists(sFile) && !File.Exists(sTarget))
                    {
                        File.Copy(sFile, sTarget);
                    }
                    else
                    {
                        //log the error 
                    }
                }
            }

            /////////////STEP 2: Transfer the executable if needed
            string sExecutableClientLocation = "NONE";
            switch (nStandardConfig)
            {
                case 0:

                    break;
                case 1:
                    sExecutableClientLocation = sLOC_SWMM;
                    break;
                case 4:
                    // 'no exe needed
                    break;

            }
            if (sExecutableClientLocation != "NONE")            //make file transfer as needed
            {
                string sEXE_Target = _sActiveHTCDir + System.IO.Path.GetFileName(sExecutableClientLocation);
                if (File.Exists(sExecutableClientLocation) && !File.Exists(sEXE_Target))
                {
                    File.Copy(sExecutableClientLocation, sEXE_Target);
                }
            }
        }

        public string getWorkingDir()
        {
            if (!bIsSimLink && _bCreateCondorRunFolder)
            {
                string sGUID = System.Guid.NewGuid().ToString();
                string sDir = _sActiveHTCDir + sGUID + "\\";
                //initialdir is not required; do not include if not requested.
                if (dictCHTC_Spec["initialdir"].ToString() != "XXX") { sDir = sDir + "\\" + dictCHTC_Spec["initialdir"].ToString(); }
                Directory.CreateDirectory(sDir);
                return sDir + "\\";
            }
            else
            {
                return _sActiveHTCDir;           //working directory is the SimLink scenario directory   (or run from submit loc)
            }

        }

        //met 8/24/2013: activeDir may not be set by getWorkingDir if using model-specific generation... 
        public void updateWorkingDir(string sTargetFile, bool bOverWriteIfAlreadySet = false)
        {
            if ((_sActiveHTCDir == "UNDEFINED") || bOverWriteIfAlreadySet)
            {
                if (CommonUtilities.cuIsFullPath(sTargetFile))
                {
                    _sActiveHTCDir = Path.GetDirectoryName(sTargetFile) + "\\";
                }
                else
                {
                    _sActiveHTCDir = Directory.GetCurrentDirectory() + "\\";
                }
            }
        }

        //met 2/3/2014: quick adapt of this code from htc_swmm
        //this runs a particular simlink command ... (like process EG or something)
        // round 1: very limited, files must be accessible on server, working directory is not generated
        // 2/5/14- revised to expect the user to supply some of this ish  (round 1)
        public virtual void PreProcessCondorJob(string[] sFileNames, string[] args)
        {
        }
 /*       public virtual void PreProcessCondorJob(string[] sFileNames, string[] args)
        {
            string sTargetInputFile = sFileNames[0];
            updateWorkingDir(sTargetInputFile, false);                //set the activeDir (if already set, it will not be modified)

            CreateBat(_sActiveHTCDir, sTargetInputFile, _SimType);
            SetExecutable(sTargetInputFile);          //add to the dictionary
            SetRequirements();
            SetFilesToTransfer(ref sFileNames);
            UpdateHTC_DictionaryByDictionary(_dictCHTC_ModelSpec);
        }
        */

        //todo: consider customization per template (certain classes)
        public Dictionary<string, string> CHTC_CreateTemplate( bool bPassEXE = false)
        {
            Dictionary<string, string> dictTemplate = new Dictionary<string,string>();
            dictTemplate.Add("universe","vanilla");
            dictTemplate.Add("requirements", "true");
            dictTemplate.Add("executable", "XXX");            //REQUIRED
            dictTemplate.Add("arguments", "");
            dictTemplate.Add("output", "run.out");
            dictTemplate.Add("error", "run.err");
            dictTemplate.Add("log", "run.log");
            dictTemplate.Add("should_transfer_files", "YES");
            dictTemplate.Add("when_to_transfer_output", "ON_EXIT");
            dictTemplate.Add("transfer_input_files", "");
            dictTemplate.Add("transfer_output_files", "XXX");
            dictTemplate.Add("initialdir", "XXX");

            if (!bPassEXE)                      //preferred, faster
            {
                switch (nStandardConfig)
                {
                    case -1:
                        //todo: log that there are no files to be managed
                        break;
                    case 1:
                        dictTemplate["executable"] = "run_swmm5.bat";
                        break;

                }

            }
            else
            {                                   //  passing the exe
                switch (nStandardConfig)
                {
                    case -1:
                        //todo: log that there are no files to be managed
                        break;
                    case 1:
                        dictTemplate["executable"] = "swmm5.exe";
                        break;

                }
            }

       //     dictTemplate.Add("queue","");
            return dictTemplate;

        }

        //overloaded HTC init: pass a Cirrus type input file
        public void InitHTC_Vars(string sFileName, string sHTC_DIR, int nStandardConfiguration = -1, bool bJobIsSimLink = false, int nTemplate = 1)
        {
            nStandardConfig = nStandardConfiguration;
     //met 8/42/2013:  this is now done in constructor     HTC_InitCommon(sHTC_DIR, bJobIsSimLink, nTemplate);
            UpdateHTC_DictionaryByFile(sFileName);
            _sActiveHTCDir = getWorkingDir();
        }

        //overloaded HTC init: pass a dictionary with relevant information
        public void InitHTC_Vars(Dictionary<string, string> dictCHTC_Input, string sHTC_DIR, int nStandardConfiguration = -1, bool bJobIsSimLink = false, int nTemplate = 1)
        {
            nStandardConfig = nStandardConfiguration;
            //met 8/42/2013:  this is now done in constructor          HTC_InitCommon(sHTC_DIR, bJobIsSimLink, nTemplate);
            UpdateHTC_DictionaryByDictionary(dictCHTC_Input);
            _sActiveHTCDir = getWorkingDir();
            condorStandardConfiguration();
          
        }

        //do application specific things to prepare the Condor 
        public void condorStandardConfiguration()
        {
            switch (nStandardConfig)
            {
                case -1:
                    //todo: log that there are no files to be managed
                    break;
                case 1:
                   /* 
                    
                    string sTarget_INP = dictCHTC_Spec["transfer_input_file"];
                    string sArg = System.IO.Path.GetFileName(sTarget_INP) + " " + sTarget_INP.Replace(".inp", ".rpt") + " " + sTarget_INP.Replace(".inp", ".out");
                    string[] s = new string[] { "swmm5.exe " + sArg };
                    string sBat = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(sTarget_INP), "run_swmm5.bat");
                    File.WriteAllLines(sBat, s); 
                    */
                    break;
            }
        }

        protected void HTC_InitCommon(string sHTC_DIR, bool bJobIsSimLink = false, int nTemplate = 1)
        {
            _sActiveHTCDir = sHTC_DIR;
            bIsSimLink = bJobIsSimLink;                                         //are we processing a SimLink job
            dictCHTC_Spec = CHTC_CreateTemplate();                     //get basic setup based on requested template
            if (_sActiveHTCDir.Substring(0, 2) == @"\\") _IsUNC = true;
        }

        public void UpdateHTC_DictionaryByDictionary(Dictionary<string, string> dictCHTC_Input)
        {
            foreach (KeyValuePair<string, string> pair in dictCHTC_Input)
            {
                if (dictCHTC_Spec.ContainsKey(pair.Key.ToString()))
                {
                    dictCHTC_Spec[pair.Key.ToString()] = pair.Value.ToString();             //update
                }
                else
                {
                    dictCHTC_Spec.Add(pair.Key.ToString(), pair.Value.ToString());          //insert
                }
            }
            dictCHTC_Spec.Add("queue", ""); 
        }

        public void UpdateHTC_DictionaryByFile(string sFileName)
        {
            if (sFileName.Substring(sFileName.Length - 4) == "xlsm")
            {
                // todo    SIM_API_Links.excel_link excelInstance = new 

            }
            else
            {   //text file
                StreamReader file = null; string sbuf; string sKey; string sVal;
                file = new StreamReader(sFileName);
                while (!file.EndOfStream)
                {
                    sbuf = file.ReadLine();
                    sKey = sbuf.Substring(0, sbuf.IndexOf('=')).ToString().Trim().Replace("chtc_", "");                        // 
                    sVal = sbuf.Substring(sbuf.IndexOf('=') + 1, sbuf.Length - sbuf.IndexOf('=') - 1).ToString().Trim();
                    if (dictCHTC_Spec.ContainsKey(sKey))
                    {
                        dictCHTC_Spec[sKey] = sVal;             //update
                    }
                    else
                    {
                        dictCHTC_Spec.Add(sKey, sVal);          //insert
                    }

                }
            }
        }

        //v1 of this function assumes ONE set of log information per run.log , ie DAG not supported at this point
        public string GetCondorJobStatus(string sFilePath, out string sCondorID, out DateTime dtCondorDate, out string sHost, out int nReturnValue)
        {
            string sCode = "xxx"; string sbuf; string sDateTemp = "";
            sHost = "NONE";
            dtCondorDate = System.DateTime.FromFileTime(1);
            nReturnValue = -1;
            sCondorID = "-1";
            StreamReader file = null;
            try
            {
                file = new StreamReader(sFilePath);
                while (!file.EndOfStream)
                {
                    sbuf = file.ReadLine();
                    if (htcLog_IsDataRow(sbuf)){
                        sCode = sbuf.Substring(0, 3);
                        sDateTemp = sbuf.Substring(18, 5) + @"/" + System.DateTime.Now.Year.ToString() + sbuf.Substring(23, 9); //yr not recorded; add current year (could be wrong!)
                        dtCondorDate = Convert.ToDateTime(sDateTemp);
                        sCondorID = sbuf.Substring(5, 11);

                        switch (sCode)
                        {
                            case "000":
                                sHost = sbuf.Substring(sbuf.IndexOf("host: <") + 7, 18);
                                break;
                            case "001":
                                sHost = sbuf.Substring(sbuf.IndexOf("host: <") + 7, 18);
                                break;    
                            case "005":
                                    sbuf = file.ReadLine();
                                    sbuf = sbuf.Substring(sbuf.IndexOf("return value") + 13, 1);
                                    nReturnValue = Convert.ToInt32(sbuf);
                                break;
                        }
                    }
                }
                return sCode;
            }
            finally
            {
                if (file != null)
                    file.Close();
            }        
        }

        private bool htcLog_IsDataRow(string sBuf)
        {
            bool bReturn = false;
            if (sBuf.Length > 3)
            {
                if (sBuf.Substring(0, 2) == "00")
                {
                    bReturn = true;
                }
            }
            return bReturn;
        }

        protected void htcCreateDictionary(string[] sArgs)
        {

        }
           #region help

    public List<string> htcGetHelp(string sArg, bool bWriteToConsole = true){
        List<string> lstReturn = new List<string>();
        switch (sArg.ToLower()){
            case "true":
                lstReturn.Add("Welcome to CirrusHTC interface for high-throughput comuting");
                lstReturn.Add("Developed by the CH2M HILL WBG, 2013. Version 1.0.");
                lstReturn.Add("You must be on the CH2M HILL domain to run CirrusHTC");
                lstReturn.Add("Specific info: CirrusHTC -help <platform>, e.g. SWMM, ExtendSim etc...");
                lstReturn.Add("*********************************");
                lstReturn.Add("CirrusHTC helps facilitate creation and submission of CondorHTC jobs.");
                lstReturn.Add("Condor must be installed on your computer to use the CLI");
                lstReturn.Add("****************   Parameters      *****************");
                lstReturn.Add("_____    ____________________________________________");
                lstReturn.Add("-f       File(s) to be included in Condor job. Required. ");
                lstReturn.Add("         Comma separated list with no spaces");
                lstReturn.Add("-req     Custom requirements in Condor format. CirrusHTC will define basic parameters, but the user can define more specific requirements. type cirrushtc -help req for examples");
                lstReturn.Add("         type cirrushtc -help req for examples");
                lstReturn.Add("-nosub   (NI) Create but do not submit to the pool.");
                break;
            case "modflow":
                lstReturn.Add("CirrusHTC supports Modflow simulations.");
                lstReturn.Add("Input1: model.bat: this must unzip files.7z, execute any required files, and then (optionally) recompress the results into a results.7z archive");
                lstReturn.Add("Input2: files.7z:  includes all necessary model files and exe");
                lstReturn.Add("Ouput1: results.7z:  compressed folder for model ouptput");
                lstReturn.Add("Zipping note: example batch code or including in model.bat");
                lstReturn.Add("              Unzip: '7z x files.7z'");  
                lstReturn.Add("              Zip (and exclude): '7z a -t7z results.7z *.* -x!files.7z'");
                lstReturn.Add("Future functionality: increased integration with SimLink for ModFlow automation");   
                break;
            case "swmm":
                lstReturn.Add("CirrusHTC supports EPA-SWMM simulations.  ");
                lstReturn.Add("Input1: filename.inp");
                lstReturn.Add("Outputs: filename.rpt, filename.out");
                lstReturn.Add("Advanced functionality: CirrusHTC can be used with SimLink to automate");
                lstReturn.Add("SWMM evaluations. Type cirrushtc -help simlink for more information");
                lstReturn.Add("SWMM Params");
                lstReturn.Add("-out     (NI) identify specific filenames to be passed back"); 
                lstReturn.Add("         Not required; enables passback of specific file only");
                break;
           case "extendsim":
                lstReturn.Add("CirrusHTC supports ExtendSim imulations. The standard configuration for a CirrusHTC SWMM job is for the user to provide a .mox file and any .lix libraries required.");
                lstReturn.Add("Because of the way Condor processes files, the input files must either be zipped or renamed during the operation (this is odd, but a requirement  for any condor job where no output file is gneerated- e.g. Excel");
                lstReturn.Add("Input1: filename.mox; any .lix files should be referenced as well");
                lstReturn.Add("Example: cirrushtc -extendsim -f file1.mox,file1.lix");
                break;
           case "condor":
                lstReturn.Add("CirrusHTC is a wrapper around HTCondor, an open-source platform for high throughput computing. CirrusHTC is  customized to support frequently perfomrmed simulation jobs");
                lstReturn.Add("Additional information about HTCondor is available at http://research.cs.wisc.edu/htcondor/ ");
                lstReturn.Add(@"Test that Condor is running by typing 'condor_status', or 'condor_q'. If it is not running, go to Computer\Manage\Services and start the Condor service");
                lstReturn.Add("Condor commands can be run from the command line to query the current status of the pool.");
                lstReturn.Add("condor_submit filename       Submit condor job");
                lstReturn.Add("condor_history      get history of jobs submittd from that machine");
                lstReturn.Add("condor_q             name condor jobs that are waiting for execution");
                lstReturn.Add("condor_q -analyze    Analyze why a specific job has not executed");
                break;
            case "simlink":
                lstReturn.Add("todo");
                break;
            case "req":
                lstReturn.Add("todo");
                break;
    }
        if (bWriteToConsole)
        {
            foreach (string s in lstReturn)
            {
                Console.WriteLine(s);
            }
        }
        return lstReturn;
}

    #endregion
    }
 


}
